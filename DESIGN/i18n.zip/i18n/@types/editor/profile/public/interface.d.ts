export declare type preferencesProtocol = 'default' | 'global' | 'local';
export declare type projectProtocol = 'default' | 'project';
export declare type tempProtocol = 'temp';
