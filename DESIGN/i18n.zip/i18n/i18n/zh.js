'use strict';

module.exports = {
    'description': '一份空白的扩展',
    'warnA': '欢迎使用 I18n 扩展',
    'warnB': '第一次启动可能会有部分警告和错误信息，不会影响具体运行',
    'warnC': '重启编辑器后，错误将会消失',
    'warnD': '如果 assets 面板没有显示，请点击 assets 面板右上角的刷新。',
};
