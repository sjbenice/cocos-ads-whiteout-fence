'use strict';

module.exports = {
    'description': 'A blank extension',
    'warnA': 'Welcome to use the I18n extension',
    'warnB': 'There may be some warnings and error messages during the first startup, which will not affect the actual operation',
    'warnB': 'When you restart the editor, the error will disappear',
    'warnC': 'If the Assets panel is not displayed, click refresh in the upper right corner of the Assets panel',
};
